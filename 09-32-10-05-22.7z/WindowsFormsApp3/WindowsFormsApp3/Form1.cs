﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        string input = string.Empty; //variable stores user input
        string operand1 = string.Empty; //variable stores first number
        string operand2 = string.Empty; //variable stores second number
        char operation;
        double result = 0.0;

        //i put this code here because the tutorial located at
        //https://www.instructables.com/Creating-a-Calculator-Visual-Studio-C/
        //has it at the top.
        public Form1()
        {
            InitializeComponent();
        }

        private void btntimestablesubmit_Click(object sender, EventArgs e)
        {
            if (txttimestable.Text == "")
                {
                MessageBox.Show("oops! you need to enter a number into the text box!");
            }
            else
            {
                double timestableinput = double.Parse(txttimestable.Text);
                double x1answer = timestableinput * 1;
                double x2answer = timestableinput * 2;
                double x3answer = timestableinput * 3;
                double x4answer = timestableinput * 4;
                double x5answer = timestableinput * 5;
                double x6answer = timestableinput * 6;
                double x7answer = timestableinput * 7;
                double x8answer = timestableinput * 8;
                double x9answer = timestableinput * 9;
                double x10answer = timestableinput * 10;
                double x11answer = timestableinput * 11;
                double x12answer = timestableinput * 12;
                lblx1answer.Text = x1answer.ToString("#.##");
                lblx2answer.Text = x2answer.ToString("#.##");
                lblx3answer.Text = x3answer.ToString("#.##");
                lblx4answer.Text = x4answer.ToString("#.##");
                lblx5answer.Text = x5answer.ToString("#.##");
                lblx6answer.Text = x6answer.ToString("#.##");
                lblx7answer.Text = x7answer.ToString("#.##");
                lblx8answer.Text = x8answer.ToString("#.##");
                lblx9answer.Text = x9answer.ToString("#.##");
                lblx10answer.Text = x10answer.ToString("#.##");
                lblx11answer.Text = x11answer.ToString("#.##");
                lblx12answer.Text = x12answer.ToString("#.##");
                //this is a absolutely horrible way to do these calculations but i
                //refuse to spend more time than necessary on this.
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtside1.Text == "" || txtside2.Text == "" || txtside3.Text == "") //are inputs empty?
            {
                lblthetriangleis.Text = "invalid";
                MessageBox.Show("oops! you need to enter a number into the text box!");
            }
            else if (txtside1.Text == txtside2.Text || txtside2.Text == txtside3.Text || txtside1.Text == txtside3.Text) // is side 1 the same as side 2 etc...?
            {
                lblthetriangleis.Text = "Isosceles";
                pbtriangle.Load("isosceles.png");
            }
            else if (txtside1.Text == txtside2.Text && txtside2.Text == txtside3.Text) // is side 1 the same as side 2 AND side 2 the same as side 3?
            {
                lblthetriangleis.Text = ("Equilateral");
                pbtriangle.Load("Equilateral.jpg");
            }
            else
            {
                lblthetriangleis.Text = ("Scalene");
                pbtriangle.Load("Scalene.png");
            }
        }

        private void lblsides_Click(object sender, EventArgs e)
        {

        }

        private void grptriangles_Enter(object sender, EventArgs e)
        {

        }

        private void btnangle_Click(object sender, EventArgs e)
        {
            double AngleNumber = double.Parse(txtangle.Text);
            if (AngleNumber == 90) // is the angle exactly 90?
            {
                lbl_angles_result.Text = ("right angle");
                pbangle.Load("rightangle.png");
            }
            if (AngleNumber == 180) // is the angle exactly 180?
            {
                lbl_angles_result.Text = ("straight angle");
                pbangle.Load("straightangle.png");
            }
            if (AngleNumber == 360) // is the angle exactly 360?
            {
                lbl_angles_result.Text = ("full rotation");
                pbangle.Load("fullrotation.png");
            }
            if (AngleNumber < 90) // is the angle below 90?
            {
                lbl_angles_result.Text = ("acute");
                pbangle.Load("acute.png");
            }
            if (AngleNumber > 90 && AngleNumber < 180) // is the angle below 180 but above 90? - note that i had to specify angle number twice, i don't understand either.
            {
                lbl_angles_result.Text = ("obtuse");
                pbangle.Load("obtuse.png");
            }
            if (AngleNumber > 180) // is the angle above 180?
            {
                lbl_angles_result.Text = ("reflex");
                pbangle.Load("reflex.png");
            }
        }

        private void btn_equals_Click(object sender, EventArgs e)
        {

        }

        private void btn_calc1_Click(object sender, EventArgs e)
        {
            input += "1";
        }
    }
}
