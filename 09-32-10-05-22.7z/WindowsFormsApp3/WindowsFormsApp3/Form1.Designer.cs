﻿namespace WindowsFormsApp3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grptimestables = new System.Windows.Forms.GroupBox();
            this.label13 = new System.Windows.Forms.Label();
            this.lbtimesinstructions = new System.Windows.Forms.Label();
            this.lblx12answer = new System.Windows.Forms.Label();
            this.lblx11answer = new System.Windows.Forms.Label();
            this.lblx10answer = new System.Windows.Forms.Label();
            this.lblx9answer = new System.Windows.Forms.Label();
            this.lblx8answer = new System.Windows.Forms.Label();
            this.lblx7answer = new System.Windows.Forms.Label();
            this.lblx6answer = new System.Windows.Forms.Label();
            this.lblx5answer = new System.Windows.Forms.Label();
            this.lblx4answer = new System.Windows.Forms.Label();
            this.lblx3answer = new System.Windows.Forms.Label();
            this.lblx2answer = new System.Windows.Forms.Label();
            this.lblx1answer = new System.Windows.Forms.Label();
            this.lblx12 = new System.Windows.Forms.Label();
            this.lblx11 = new System.Windows.Forms.Label();
            this.lblx10 = new System.Windows.Forms.Label();
            this.lblx9 = new System.Windows.Forms.Label();
            this.lblx8 = new System.Windows.Forms.Label();
            this.lblx7 = new System.Windows.Forms.Label();
            this.lblx6 = new System.Windows.Forms.Label();
            this.lblx5 = new System.Windows.Forms.Label();
            this.lblx4 = new System.Windows.Forms.Label();
            this.lblx3 = new System.Windows.Forms.Label();
            this.lblx2 = new System.Windows.Forms.Label();
            this.lblx1 = new System.Windows.Forms.Label();
            this.btntimestablesubmit = new System.Windows.Forms.Button();
            this.txttimestable = new System.Windows.Forms.TextBox();
            this.lblrtimetableesult = new System.Windows.Forms.Label();
            this.grptriangles = new System.Windows.Forms.GroupBox();
            this.lbl_triangles_instructions_main = new System.Windows.Forms.Label();
            this.lbl_triangles_instructionsheader = new System.Windows.Forms.Label();
            this.pbtriangle = new System.Windows.Forms.PictureBox();
            this.lblthetriangleis = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.lblsides = new System.Windows.Forms.Label();
            this.txtside3 = new System.Windows.Forms.TextBox();
            this.txtside2 = new System.Windows.Forms.TextBox();
            this.txtside1 = new System.Windows.Forms.TextBox();
            this.grpangles = new System.Windows.Forms.GroupBox();
            this.lbl_angles_result = new System.Windows.Forms.Label();
            this.pbangle = new System.Windows.Forms.PictureBox();
            this.lblangleresult = new System.Windows.Forms.Label();
            this.lbl_the_angle_label = new System.Windows.Forms.Label();
            this.btnangle = new System.Windows.Forms.Button();
            this.lbl_angle_instructions_main = new System.Windows.Forms.Label();
            this.lbl_instructions_angles_header = new System.Windows.Forms.Label();
            this.txtangle = new System.Windows.Forms.TextBox();
            this.grp_calc = new System.Windows.Forms.GroupBox();
            this.btn_calc3 = new System.Windows.Forms.Button();
            this.btn_multiply = new System.Windows.Forms.Button();
            this.btn_divide = new System.Windows.Forms.Button();
            this.btn_minus = new System.Windows.Forms.Button();
            this.btn_plus = new System.Windows.Forms.Button();
            this.btn_calc6 = new System.Windows.Forms.Button();
            this.btn_calc2 = new System.Windows.Forms.Button();
            this.btn_calc1 = new System.Windows.Forms.Button();
            this.btn_num9 = new System.Windows.Forms.Button();
            this.btn_calc5 = new System.Windows.Forms.Button();
            this.btn_calc4 = new System.Windows.Forms.Button();
            this.btn_equals = new System.Windows.Forms.Button();
            this.btn_calc8 = new System.Windows.Forms.Button();
            this.btn_calc7 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.grptimestables.SuspendLayout();
            this.grptriangles.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbtriangle)).BeginInit();
            this.grpangles.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbangle)).BeginInit();
            this.grp_calc.SuspendLayout();
            this.SuspendLayout();
            // 
            // grptimestables
            // 
            this.grptimestables.Controls.Add(this.label13);
            this.grptimestables.Controls.Add(this.lbtimesinstructions);
            this.grptimestables.Controls.Add(this.lblx12answer);
            this.grptimestables.Controls.Add(this.lblx11answer);
            this.grptimestables.Controls.Add(this.lblx10answer);
            this.grptimestables.Controls.Add(this.lblx9answer);
            this.grptimestables.Controls.Add(this.lblx8answer);
            this.grptimestables.Controls.Add(this.lblx7answer);
            this.grptimestables.Controls.Add(this.lblx6answer);
            this.grptimestables.Controls.Add(this.lblx5answer);
            this.grptimestables.Controls.Add(this.lblx4answer);
            this.grptimestables.Controls.Add(this.lblx3answer);
            this.grptimestables.Controls.Add(this.lblx2answer);
            this.grptimestables.Controls.Add(this.lblx1answer);
            this.grptimestables.Controls.Add(this.lblx12);
            this.grptimestables.Controls.Add(this.lblx11);
            this.grptimestables.Controls.Add(this.lblx10);
            this.grptimestables.Controls.Add(this.lblx9);
            this.grptimestables.Controls.Add(this.lblx8);
            this.grptimestables.Controls.Add(this.lblx7);
            this.grptimestables.Controls.Add(this.lblx6);
            this.grptimestables.Controls.Add(this.lblx5);
            this.grptimestables.Controls.Add(this.lblx4);
            this.grptimestables.Controls.Add(this.lblx3);
            this.grptimestables.Controls.Add(this.lblx2);
            this.grptimestables.Controls.Add(this.lblx1);
            this.grptimestables.Controls.Add(this.btntimestablesubmit);
            this.grptimestables.Controls.Add(this.txttimestable);
            this.grptimestables.Controls.Add(this.lblrtimetableesult);
            this.grptimestables.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grptimestables.Location = new System.Drawing.Point(33, 13);
            this.grptimestables.Name = "grptimestables";
            this.grptimestables.Size = new System.Drawing.Size(350, 293);
            this.grptimestables.TabIndex = 0;
            this.grptimestables.TabStop = false;
            this.grptimestables.Text = "times table";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Comic Sans MS", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(2, 225);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(207, 40);
            this.label13.TabIndex = 28;
            this.label13.Text = "enter a number into the text\r\nbox then click the button";
            // 
            // lbtimesinstructions
            // 
            this.lbtimesinstructions.AutoSize = true;
            this.lbtimesinstructions.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbtimesinstructions.Location = new System.Drawing.Point(2, 199);
            this.lbtimesinstructions.Name = "lbtimesinstructions";
            this.lbtimesinstructions.Size = new System.Drawing.Size(96, 23);
            this.lbtimesinstructions.TabIndex = 27;
            this.lbtimesinstructions.Text = "instructions";
            // 
            // lblx12answer
            // 
            this.lblx12answer.AutoSize = true;
            this.lblx12answer.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx12answer.Location = new System.Drawing.Point(263, 258);
            this.lblx12answer.Name = "lblx12answer";
            this.lblx12answer.Size = new System.Drawing.Size(81, 23);
            this.lblx12answer.TabIndex = 26;
            this.lblx12answer.Text = "undefined";
            // 
            // lblx11answer
            // 
            this.lblx11answer.AutoSize = true;
            this.lblx11answer.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx11answer.Location = new System.Drawing.Point(263, 238);
            this.lblx11answer.Name = "lblx11answer";
            this.lblx11answer.Size = new System.Drawing.Size(81, 23);
            this.lblx11answer.TabIndex = 25;
            this.lblx11answer.Text = "undefined";
            // 
            // lblx10answer
            // 
            this.lblx10answer.AutoSize = true;
            this.lblx10answer.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx10answer.Location = new System.Drawing.Point(263, 218);
            this.lblx10answer.Name = "lblx10answer";
            this.lblx10answer.Size = new System.Drawing.Size(81, 23);
            this.lblx10answer.TabIndex = 24;
            this.lblx10answer.Text = "undefined";
            // 
            // lblx9answer
            // 
            this.lblx9answer.AutoSize = true;
            this.lblx9answer.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx9answer.Location = new System.Drawing.Point(263, 198);
            this.lblx9answer.Name = "lblx9answer";
            this.lblx9answer.Size = new System.Drawing.Size(81, 23);
            this.lblx9answer.TabIndex = 23;
            this.lblx9answer.Text = "undefined";
            // 
            // lblx8answer
            // 
            this.lblx8answer.AutoSize = true;
            this.lblx8answer.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx8answer.Location = new System.Drawing.Point(261, 178);
            this.lblx8answer.Name = "lblx8answer";
            this.lblx8answer.Size = new System.Drawing.Size(81, 23);
            this.lblx8answer.TabIndex = 22;
            this.lblx8answer.Text = "undefined";
            // 
            // lblx7answer
            // 
            this.lblx7answer.AutoSize = true;
            this.lblx7answer.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx7answer.Location = new System.Drawing.Point(263, 158);
            this.lblx7answer.Name = "lblx7answer";
            this.lblx7answer.Size = new System.Drawing.Size(81, 23);
            this.lblx7answer.TabIndex = 21;
            this.lblx7answer.Text = "undefined";
            // 
            // lblx6answer
            // 
            this.lblx6answer.AutoSize = true;
            this.lblx6answer.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx6answer.Location = new System.Drawing.Point(263, 138);
            this.lblx6answer.Name = "lblx6answer";
            this.lblx6answer.Size = new System.Drawing.Size(81, 23);
            this.lblx6answer.TabIndex = 20;
            this.lblx6answer.Text = "undefined";
            // 
            // lblx5answer
            // 
            this.lblx5answer.AutoSize = true;
            this.lblx5answer.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx5answer.Location = new System.Drawing.Point(263, 118);
            this.lblx5answer.Name = "lblx5answer";
            this.lblx5answer.Size = new System.Drawing.Size(81, 23);
            this.lblx5answer.TabIndex = 19;
            this.lblx5answer.Text = "undefined";
            // 
            // lblx4answer
            // 
            this.lblx4answer.AutoSize = true;
            this.lblx4answer.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx4answer.Location = new System.Drawing.Point(264, 96);
            this.lblx4answer.Name = "lblx4answer";
            this.lblx4answer.Size = new System.Drawing.Size(81, 23);
            this.lblx4answer.TabIndex = 18;
            this.lblx4answer.Text = "undefined";
            // 
            // lblx3answer
            // 
            this.lblx3answer.AutoSize = true;
            this.lblx3answer.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx3answer.Location = new System.Drawing.Point(263, 76);
            this.lblx3answer.Name = "lblx3answer";
            this.lblx3answer.Size = new System.Drawing.Size(81, 23);
            this.lblx3answer.TabIndex = 17;
            this.lblx3answer.Text = "undefined";
            // 
            // lblx2answer
            // 
            this.lblx2answer.AutoSize = true;
            this.lblx2answer.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx2answer.Location = new System.Drawing.Point(264, 56);
            this.lblx2answer.Name = "lblx2answer";
            this.lblx2answer.Size = new System.Drawing.Size(81, 23);
            this.lblx2answer.TabIndex = 16;
            this.lblx2answer.Text = "undefined";
            // 
            // lblx1answer
            // 
            this.lblx1answer.AutoSize = true;
            this.lblx1answer.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx1answer.Location = new System.Drawing.Point(264, 36);
            this.lblx1answer.Name = "lblx1answer";
            this.lblx1answer.Size = new System.Drawing.Size(81, 23);
            this.lblx1answer.TabIndex = 15;
            this.lblx1answer.Text = "undefined";
            // 
            // lblx12
            // 
            this.lblx12.AutoSize = true;
            this.lblx12.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx12.Location = new System.Drawing.Point(219, 258);
            this.lblx12.Name = "lblx12";
            this.lblx12.Size = new System.Drawing.Size(49, 23);
            this.lblx12.TabIndex = 14;
            this.lblx12.Text = "x12 =";
            // 
            // lblx11
            // 
            this.lblx11.AutoSize = true;
            this.lblx11.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx11.Location = new System.Drawing.Point(219, 238);
            this.lblx11.Name = "lblx11";
            this.lblx11.Size = new System.Drawing.Size(46, 23);
            this.lblx11.TabIndex = 13;
            this.lblx11.Text = "x11 =";
            // 
            // lblx10
            // 
            this.lblx10.AutoSize = true;
            this.lblx10.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx10.Location = new System.Drawing.Point(219, 218);
            this.lblx10.Name = "lblx10";
            this.lblx10.Size = new System.Drawing.Size(49, 23);
            this.lblx10.TabIndex = 12;
            this.lblx10.Text = "x10 =";
            // 
            // lblx9
            // 
            this.lblx9.AutoSize = true;
            this.lblx9.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx9.Location = new System.Drawing.Point(219, 198);
            this.lblx9.Name = "lblx9";
            this.lblx9.Size = new System.Drawing.Size(42, 23);
            this.lblx9.TabIndex = 11;
            this.lblx9.Text = "x9 =";
            // 
            // lblx8
            // 
            this.lblx8.AutoSize = true;
            this.lblx8.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx8.Location = new System.Drawing.Point(217, 178);
            this.lblx8.Name = "lblx8";
            this.lblx8.Size = new System.Drawing.Size(42, 23);
            this.lblx8.TabIndex = 10;
            this.lblx8.Text = "x8 =";
            // 
            // lblx7
            // 
            this.lblx7.AutoSize = true;
            this.lblx7.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx7.Location = new System.Drawing.Point(219, 158);
            this.lblx7.Name = "lblx7";
            this.lblx7.Size = new System.Drawing.Size(42, 23);
            this.lblx7.TabIndex = 9;
            this.lblx7.Text = "x7 =";
            // 
            // lblx6
            // 
            this.lblx6.AutoSize = true;
            this.lblx6.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx6.Location = new System.Drawing.Point(219, 138);
            this.lblx6.Name = "lblx6";
            this.lblx6.Size = new System.Drawing.Size(42, 23);
            this.lblx6.TabIndex = 8;
            this.lblx6.Text = "x6 =";
            // 
            // lblx5
            // 
            this.lblx5.AutoSize = true;
            this.lblx5.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx5.Location = new System.Drawing.Point(219, 118);
            this.lblx5.Name = "lblx5";
            this.lblx5.Size = new System.Drawing.Size(42, 23);
            this.lblx5.TabIndex = 7;
            this.lblx5.Text = "x5 =";
            // 
            // lblx4
            // 
            this.lblx4.AutoSize = true;
            this.lblx4.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx4.Location = new System.Drawing.Point(220, 96);
            this.lblx4.Name = "lblx4";
            this.lblx4.Size = new System.Drawing.Size(42, 23);
            this.lblx4.TabIndex = 6;
            this.lblx4.Text = "x4 =";
            // 
            // lblx3
            // 
            this.lblx3.AutoSize = true;
            this.lblx3.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx3.Location = new System.Drawing.Point(217, 76);
            this.lblx3.Name = "lblx3";
            this.lblx3.Size = new System.Drawing.Size(42, 23);
            this.lblx3.TabIndex = 5;
            this.lblx3.Text = "x3 =";
            // 
            // lblx2
            // 
            this.lblx2.AutoSize = true;
            this.lblx2.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx2.Location = new System.Drawing.Point(220, 56);
            this.lblx2.Name = "lblx2";
            this.lblx2.Size = new System.Drawing.Size(42, 23);
            this.lblx2.TabIndex = 4;
            this.lblx2.Text = "x2 =";
            // 
            // lblx1
            // 
            this.lblx1.AutoSize = true;
            this.lblx1.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx1.Location = new System.Drawing.Point(220, 36);
            this.lblx1.Name = "lblx1";
            this.lblx1.Size = new System.Drawing.Size(39, 23);
            this.lblx1.TabIndex = 3;
            this.lblx1.Text = "x1 =";
            // 
            // btntimestablesubmit
            // 
            this.btntimestablesubmit.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btntimestablesubmit.Location = new System.Drawing.Point(112, 19);
            this.btntimestablesubmit.Name = "btntimestablesubmit";
            this.btntimestablesubmit.Size = new System.Drawing.Size(75, 34);
            this.btntimestablesubmit.TabIndex = 2;
            this.btntimestablesubmit.Text = "submit";
            this.btntimestablesubmit.UseVisualStyleBackColor = true;
            this.btntimestablesubmit.Click += new System.EventHandler(this.btntimestablesubmit_Click);
            // 
            // txttimestable
            // 
            this.txttimestable.Location = new System.Drawing.Point(6, 28);
            this.txttimestable.Name = "txttimestable";
            this.txttimestable.Size = new System.Drawing.Size(100, 23);
            this.txttimestable.TabIndex = 1;
            // 
            // lblrtimetableesult
            // 
            this.lblrtimetableesult.AutoSize = true;
            this.lblrtimetableesult.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblrtimetableesult.Location = new System.Drawing.Point(219, 13);
            this.lblrtimetableesult.Name = "lblrtimetableesult";
            this.lblrtimetableesult.Size = new System.Drawing.Size(61, 23);
            this.lblrtimetableesult.TabIndex = 0;
            this.lblrtimetableesult.Text = "Result:";
            // 
            // grptriangles
            // 
            this.grptriangles.Controls.Add(this.lbl_triangles_instructions_main);
            this.grptriangles.Controls.Add(this.lbl_triangles_instructionsheader);
            this.grptriangles.Controls.Add(this.pbtriangle);
            this.grptriangles.Controls.Add(this.lblthetriangleis);
            this.grptriangles.Controls.Add(this.button1);
            this.grptriangles.Controls.Add(this.lblsides);
            this.grptriangles.Controls.Add(this.txtside3);
            this.grptriangles.Controls.Add(this.txtside2);
            this.grptriangles.Controls.Add(this.txtside1);
            this.grptriangles.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grptriangles.Location = new System.Drawing.Point(404, 13);
            this.grptriangles.Name = "grptriangles";
            this.grptriangles.Size = new System.Drawing.Size(461, 272);
            this.grptriangles.TabIndex = 1;
            this.grptriangles.TabStop = false;
            this.grptriangles.Text = "triangles";
            this.grptriangles.Enter += new System.EventHandler(this.grptriangles_Enter);
            // 
            // lbl_triangles_instructions_main
            // 
            this.lbl_triangles_instructions_main.AutoSize = true;
            this.lbl_triangles_instructions_main.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_triangles_instructions_main.Location = new System.Drawing.Point(7, 223);
            this.lbl_triangles_instructions_main.Name = "lbl_triangles_instructions_main";
            this.lbl_triangles_instructions_main.Size = new System.Drawing.Size(259, 46);
            this.lbl_triangles_instructions_main.TabIndex = 30;
            this.lbl_triangles_instructions_main.Text = "enter the numbers into the 3 text \r\nboxes provided and click submit.";
            // 
            // lbl_triangles_instructionsheader
            // 
            this.lbl_triangles_instructionsheader.AutoSize = true;
            this.lbl_triangles_instructionsheader.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_triangles_instructionsheader.Location = new System.Drawing.Point(3, 199);
            this.lbl_triangles_instructionsheader.Name = "lbl_triangles_instructionsheader";
            this.lbl_triangles_instructionsheader.Size = new System.Drawing.Size(96, 23);
            this.lbl_triangles_instructionsheader.TabIndex = 29;
            this.lbl_triangles_instructionsheader.Text = "instructions";
            // 
            // pbtriangle
            // 
            this.pbtriangle.Location = new System.Drawing.Point(252, 13);
            this.pbtriangle.Name = "pbtriangle";
            this.pbtriangle.Size = new System.Drawing.Size(209, 209);
            this.pbtriangle.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbtriangle.TabIndex = 6;
            this.pbtriangle.TabStop = false;
            // 
            // lblthetriangleis
            // 
            this.lblthetriangleis.AutoSize = true;
            this.lblthetriangleis.Location = new System.Drawing.Point(7, 121);
            this.lblthetriangleis.Name = "lblthetriangleis";
            this.lblthetriangleis.Size = new System.Drawing.Size(0, 15);
            this.lblthetriangleis.TabIndex = 5;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(113, 54);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 30);
            this.button1.TabIndex = 4;
            this.button1.Text = "submit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblsides
            // 
            this.lblsides.AutoSize = true;
            this.lblsides.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsides.Location = new System.Drawing.Point(7, 121);
            this.lblsides.Name = "lblsides";
            this.lblsides.Size = new System.Drawing.Size(124, 23);
            this.lblsides.TabIndex = 3;
            this.lblsides.Text = "the triangle is...";
            this.lblsides.Click += new System.EventHandler(this.lblsides_Click);
            // 
            // txtside3
            // 
            this.txtside3.Location = new System.Drawing.Point(6, 91);
            this.txtside3.Name = "txtside3";
            this.txtside3.Size = new System.Drawing.Size(100, 23);
            this.txtside3.TabIndex = 2;
            // 
            // txtside2
            // 
            this.txtside2.Location = new System.Drawing.Point(7, 55);
            this.txtside2.Name = "txtside2";
            this.txtside2.Size = new System.Drawing.Size(100, 23);
            this.txtside2.TabIndex = 1;
            // 
            // txtside1
            // 
            this.txtside1.Location = new System.Drawing.Point(7, 19);
            this.txtside1.Name = "txtside1";
            this.txtside1.Size = new System.Drawing.Size(100, 23);
            this.txtside1.TabIndex = 0;
            // 
            // grpangles
            // 
            this.grpangles.Controls.Add(this.lbl_angles_result);
            this.grpangles.Controls.Add(this.pbangle);
            this.grpangles.Controls.Add(this.lblangleresult);
            this.grpangles.Controls.Add(this.lbl_the_angle_label);
            this.grpangles.Controls.Add(this.btnangle);
            this.grpangles.Controls.Add(this.lbl_angle_instructions_main);
            this.grpangles.Controls.Add(this.lbl_instructions_angles_header);
            this.grpangles.Controls.Add(this.txtangle);
            this.grpangles.Font = new System.Drawing.Font("Comic Sans MS", 8.25F);
            this.grpangles.Location = new System.Drawing.Point(33, 312);
            this.grpangles.Name = "grpangles";
            this.grpangles.Size = new System.Drawing.Size(350, 281);
            this.grpangles.TabIndex = 2;
            this.grpangles.TabStop = false;
            this.grpangles.Text = "angles";
            // 
            // lbl_angles_result
            // 
            this.lbl_angles_result.AutoSize = true;
            this.lbl_angles_result.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_angles_result.Location = new System.Drawing.Point(8, 84);
            this.lbl_angles_result.Name = "lbl_angles_result";
            this.lbl_angles_result.Size = new System.Drawing.Size(140, 23);
            this.lbl_angles_result.TabIndex = 34;
            this.lbl_angles_result.Text = "no angle specified";
            // 
            // pbangle
            // 
            this.pbangle.Location = new System.Drawing.Point(173, 63);
            this.pbangle.Name = "pbangle";
            this.pbangle.Size = new System.Drawing.Size(170, 149);
            this.pbangle.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbangle.TabIndex = 33;
            this.pbangle.TabStop = false;
            // 
            // lblangleresult
            // 
            this.lblangleresult.AutoSize = true;
            this.lblangleresult.Location = new System.Drawing.Point(8, 63);
            this.lblangleresult.Name = "lblangleresult";
            this.lblangleresult.Size = new System.Drawing.Size(0, 15);
            this.lblangleresult.TabIndex = 32;
            // 
            // lbl_the_angle_label
            // 
            this.lbl_the_angle_label.AutoSize = true;
            this.lbl_the_angle_label.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_the_angle_label.Location = new System.Drawing.Point(7, 61);
            this.lbl_the_angle_label.Name = "lbl_the_angle_label";
            this.lbl_the_angle_label.Size = new System.Drawing.Size(104, 23);
            this.lbl_the_angle_label.TabIndex = 31;
            this.lbl_the_angle_label.Text = "the angle is...";
            // 
            // btnangle
            // 
            this.btnangle.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnangle.Location = new System.Drawing.Point(117, 20);
            this.btnangle.Name = "btnangle";
            this.btnangle.Size = new System.Drawing.Size(75, 30);
            this.btnangle.TabIndex = 31;
            this.btnangle.Text = "submit";
            this.btnangle.UseVisualStyleBackColor = true;
            this.btnangle.Click += new System.EventHandler(this.btnangle_Click);
            // 
            // lbl_angle_instructions_main
            // 
            this.lbl_angle_instructions_main.AutoSize = true;
            this.lbl_angle_instructions_main.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_angle_instructions_main.Location = new System.Drawing.Point(2, 232);
            this.lbl_angle_instructions_main.Name = "lbl_angle_instructions_main";
            this.lbl_angle_instructions_main.Size = new System.Drawing.Size(249, 46);
            this.lbl_angle_instructions_main.TabIndex = 30;
            this.lbl_angle_instructions_main.Text = "enter a number into the text box\r\nthen click the button";
            // 
            // lbl_instructions_angles_header
            // 
            this.lbl_instructions_angles_header.AutoSize = true;
            this.lbl_instructions_angles_header.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_instructions_angles_header.Location = new System.Drawing.Point(5, 206);
            this.lbl_instructions_angles_header.Name = "lbl_instructions_angles_header";
            this.lbl_instructions_angles_header.Size = new System.Drawing.Size(113, 26);
            this.lbl_instructions_angles_header.TabIndex = 29;
            this.lbl_instructions_angles_header.Text = "instructions";
            // 
            // txtangle
            // 
            this.txtangle.Location = new System.Drawing.Point(10, 20);
            this.txtangle.Name = "txtangle";
            this.txtangle.Size = new System.Drawing.Size(100, 23);
            this.txtangle.TabIndex = 0;
            // 
            // grp_calc
            // 
            this.grp_calc.Controls.Add(this.textBox1);
            this.grp_calc.Controls.Add(this.btn_calc3);
            this.grp_calc.Controls.Add(this.btn_multiply);
            this.grp_calc.Controls.Add(this.btn_divide);
            this.grp_calc.Controls.Add(this.btn_minus);
            this.grp_calc.Controls.Add(this.btn_plus);
            this.grp_calc.Controls.Add(this.btn_calc6);
            this.grp_calc.Controls.Add(this.btn_calc2);
            this.grp_calc.Controls.Add(this.btn_calc1);
            this.grp_calc.Controls.Add(this.btn_num9);
            this.grp_calc.Controls.Add(this.btn_calc5);
            this.grp_calc.Controls.Add(this.btn_calc4);
            this.grp_calc.Controls.Add(this.btn_equals);
            this.grp_calc.Controls.Add(this.btn_calc8);
            this.grp_calc.Controls.Add(this.btn_calc7);
            this.grp_calc.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grp_calc.Location = new System.Drawing.Point(468, 332);
            this.grp_calc.Name = "grp_calc";
            this.grp_calc.Size = new System.Drawing.Size(348, 232);
            this.grp_calc.TabIndex = 3;
            this.grp_calc.TabStop = false;
            this.grp_calc.Text = "calculator";
            // 
            // btn_calc3
            // 
            this.btn_calc3.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_calc3.Location = new System.Drawing.Point(186, 179);
            this.btn_calc3.Name = "btn_calc3";
            this.btn_calc3.Size = new System.Drawing.Size(75, 33);
            this.btn_calc3.TabIndex = 13;
            this.btn_calc3.Text = "3";
            this.btn_calc3.UseVisualStyleBackColor = true;
            // 
            // btn_multiply
            // 
            this.btn_multiply.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_multiply.Location = new System.Drawing.Point(265, 178);
            this.btn_multiply.Name = "btn_multiply";
            this.btn_multiply.Size = new System.Drawing.Size(75, 33);
            this.btn_multiply.TabIndex = 12;
            this.btn_multiply.Text = "X";
            this.btn_multiply.UseVisualStyleBackColor = true;
            // 
            // btn_divide
            // 
            this.btn_divide.Font = new System.Drawing.Font("Comic Sans MS", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_divide.Location = new System.Drawing.Point(265, 141);
            this.btn_divide.Name = "btn_divide";
            this.btn_divide.Size = new System.Drawing.Size(75, 33);
            this.btn_divide.TabIndex = 11;
            this.btn_divide.Text = "÷";
            this.btn_divide.UseVisualStyleBackColor = true;
            // 
            // btn_minus
            // 
            this.btn_minus.Font = new System.Drawing.Font("Comic Sans MS", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_minus.Location = new System.Drawing.Point(267, 102);
            this.btn_minus.Name = "btn_minus";
            this.btn_minus.Size = new System.Drawing.Size(75, 33);
            this.btn_minus.TabIndex = 10;
            this.btn_minus.Text = "-";
            this.btn_minus.UseVisualStyleBackColor = true;
            // 
            // btn_plus
            // 
            this.btn_plus.Font = new System.Drawing.Font("Comic Sans MS", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_plus.Location = new System.Drawing.Point(267, 63);
            this.btn_plus.Name = "btn_plus";
            this.btn_plus.Size = new System.Drawing.Size(75, 33);
            this.btn_plus.TabIndex = 9;
            this.btn_plus.Text = "+";
            this.btn_plus.UseVisualStyleBackColor = true;
            // 
            // btn_calc6
            // 
            this.btn_calc6.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_calc6.Location = new System.Drawing.Point(186, 141);
            this.btn_calc6.Name = "btn_calc6";
            this.btn_calc6.Size = new System.Drawing.Size(75, 32);
            this.btn_calc6.TabIndex = 8;
            this.btn_calc6.Text = "6";
            this.btn_calc6.UseVisualStyleBackColor = true;
            // 
            // btn_calc2
            // 
            this.btn_calc2.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_calc2.Location = new System.Drawing.Point(105, 179);
            this.btn_calc2.Name = "btn_calc2";
            this.btn_calc2.Size = new System.Drawing.Size(75, 32);
            this.btn_calc2.TabIndex = 7;
            this.btn_calc2.Text = "2";
            this.btn_calc2.UseVisualStyleBackColor = true;
            // 
            // btn_calc1
            // 
            this.btn_calc1.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_calc1.Location = new System.Drawing.Point(24, 179);
            this.btn_calc1.Name = "btn_calc1";
            this.btn_calc1.Size = new System.Drawing.Size(75, 32);
            this.btn_calc1.TabIndex = 6;
            this.btn_calc1.Text = "1";
            this.btn_calc1.UseVisualStyleBackColor = true;
            this.btn_calc1.Click += new System.EventHandler(this.btn_calc1_Click);
            // 
            // btn_num9
            // 
            this.btn_num9.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_num9.Location = new System.Drawing.Point(186, 102);
            this.btn_num9.Name = "btn_num9";
            this.btn_num9.Size = new System.Drawing.Size(75, 33);
            this.btn_num9.TabIndex = 5;
            this.btn_num9.Text = "9";
            this.btn_num9.UseVisualStyleBackColor = true;
            // 
            // btn_calc5
            // 
            this.btn_calc5.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_calc5.Location = new System.Drawing.Point(105, 140);
            this.btn_calc5.Name = "btn_calc5";
            this.btn_calc5.Size = new System.Drawing.Size(75, 33);
            this.btn_calc5.TabIndex = 4;
            this.btn_calc5.Text = "5";
            this.btn_calc5.UseVisualStyleBackColor = true;
            // 
            // btn_calc4
            // 
            this.btn_calc4.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_calc4.Location = new System.Drawing.Point(24, 141);
            this.btn_calc4.Name = "btn_calc4";
            this.btn_calc4.Size = new System.Drawing.Size(75, 33);
            this.btn_calc4.TabIndex = 3;
            this.btn_calc4.Text = "4";
            this.btn_calc4.UseVisualStyleBackColor = true;
            // 
            // btn_equals
            // 
            this.btn_equals.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_equals.Location = new System.Drawing.Point(186, 63);
            this.btn_equals.Name = "btn_equals";
            this.btn_equals.Size = new System.Drawing.Size(75, 33);
            this.btn_equals.TabIndex = 2;
            this.btn_equals.Text = "=";
            this.btn_equals.UseVisualStyleBackColor = true;
            this.btn_equals.Click += new System.EventHandler(this.btn_equals_Click);
            // 
            // btn_calc8
            // 
            this.btn_calc8.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_calc8.Location = new System.Drawing.Point(105, 101);
            this.btn_calc8.Name = "btn_calc8";
            this.btn_calc8.Size = new System.Drawing.Size(75, 33);
            this.btn_calc8.TabIndex = 1;
            this.btn_calc8.Text = "8";
            this.btn_calc8.UseVisualStyleBackColor = true;
            // 
            // btn_calc7
            // 
            this.btn_calc7.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_calc7.Location = new System.Drawing.Point(24, 101);
            this.btn_calc7.Name = "btn_calc7";
            this.btn_calc7.Size = new System.Drawing.Size(75, 33);
            this.btn_calc7.TabIndex = 0;
            this.btn_calc7.Text = "7";
            this.btn_calc7.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(11, 27);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(331, 23);
            this.textBox1.TabIndex = 14;
            this.textBox1.Text = "txtcalc";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightCyan;
            this.ClientSize = new System.Drawing.Size(891, 611);
            this.Controls.Add(this.grp_calc);
            this.Controls.Add(this.grpangles);
            this.Controls.Add(this.grptriangles);
            this.Controls.Add(this.grptimestables);
            this.Name = "Form1";
            this.Text = "Form1";
            this.grptimestables.ResumeLayout(false);
            this.grptimestables.PerformLayout();
            this.grptriangles.ResumeLayout(false);
            this.grptriangles.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbtriangle)).EndInit();
            this.grpangles.ResumeLayout(false);
            this.grpangles.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbangle)).EndInit();
            this.grp_calc.ResumeLayout(false);
            this.grp_calc.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grptimestables;
        private System.Windows.Forms.Label lblx7;
        private System.Windows.Forms.Label lblx6;
        private System.Windows.Forms.Label lblx5;
        private System.Windows.Forms.Label lblx4;
        private System.Windows.Forms.Label lblx3;
        private System.Windows.Forms.Label lblx2;
        private System.Windows.Forms.Label lblx1;
        private System.Windows.Forms.Button btntimestablesubmit;
        private System.Windows.Forms.TextBox txttimestable;
        private System.Windows.Forms.Label lblrtimetableesult;
        private System.Windows.Forms.Label lblx12;
        private System.Windows.Forms.Label lblx11;
        private System.Windows.Forms.Label lblx10;
        private System.Windows.Forms.Label lblx9;
        private System.Windows.Forms.Label lblx8;
        private System.Windows.Forms.Label lblx12answer;
        private System.Windows.Forms.Label lblx11answer;
        private System.Windows.Forms.Label lblx10answer;
        private System.Windows.Forms.Label lblx9answer;
        private System.Windows.Forms.Label lblx8answer;
        private System.Windows.Forms.Label lblx7answer;
        private System.Windows.Forms.Label lblx6answer;
        private System.Windows.Forms.Label lblx5answer;
        private System.Windows.Forms.Label lblx4answer;
        private System.Windows.Forms.Label lblx3answer;
        private System.Windows.Forms.Label lblx2answer;
        private System.Windows.Forms.Label lblx1answer;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lbtimesinstructions;
        private System.Windows.Forms.GroupBox grptriangles;
        private System.Windows.Forms.TextBox txtside3;
        private System.Windows.Forms.TextBox txtside2;
        private System.Windows.Forms.TextBox txtside1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lblsides;
        private System.Windows.Forms.Label lblthetriangleis;
        private System.Windows.Forms.PictureBox pbtriangle;
        private System.Windows.Forms.GroupBox grpangles;
        private System.Windows.Forms.Label lbl_triangles_instructions_main;
        private System.Windows.Forms.Label lbl_triangles_instructionsheader;
        private System.Windows.Forms.Button btnangle;
        private System.Windows.Forms.Label lbl_angle_instructions_main;
        private System.Windows.Forms.Label lbl_instructions_angles_header;
        private System.Windows.Forms.TextBox txtangle;
        private System.Windows.Forms.Label lblangleresult;
        private System.Windows.Forms.Label lbl_the_angle_label;
        private System.Windows.Forms.PictureBox pbangle;
        private System.Windows.Forms.Label lbl_angles_result;
        private System.Windows.Forms.GroupBox grp_calc;
        private System.Windows.Forms.Button btn_calc6;
        private System.Windows.Forms.Button btn_calc2;
        private System.Windows.Forms.Button btn_calc1;
        private System.Windows.Forms.Button btn_num9;
        private System.Windows.Forms.Button btn_calc5;
        private System.Windows.Forms.Button btn_calc4;
        private System.Windows.Forms.Button btn_equals;
        private System.Windows.Forms.Button btn_calc8;
        private System.Windows.Forms.Button btn_calc7;
        private System.Windows.Forms.Button btn_calc3;
        private System.Windows.Forms.Button btn_multiply;
        private System.Windows.Forms.Button btn_divide;
        private System.Windows.Forms.Button btn_minus;
        private System.Windows.Forms.Button btn_plus;
        private System.Windows.Forms.TextBox textBox1;
    }
}

