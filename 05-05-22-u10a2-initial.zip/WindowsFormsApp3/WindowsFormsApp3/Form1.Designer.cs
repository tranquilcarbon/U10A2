﻿namespace WindowsFormsApp3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grptimestables = new System.Windows.Forms.GroupBox();
            this.lblrtimetableesult = new System.Windows.Forms.Label();
            this.txttimestable = new System.Windows.Forms.TextBox();
            this.btntimestablesubmit = new System.Windows.Forms.Button();
            this.lblx1 = new System.Windows.Forms.Label();
            this.lblx2 = new System.Windows.Forms.Label();
            this.lblx3 = new System.Windows.Forms.Label();
            this.lblx4 = new System.Windows.Forms.Label();
            this.lblx5 = new System.Windows.Forms.Label();
            this.lblx6 = new System.Windows.Forms.Label();
            this.lblx7 = new System.Windows.Forms.Label();
            this.lblx8 = new System.Windows.Forms.Label();
            this.lblx9 = new System.Windows.Forms.Label();
            this.lblx10 = new System.Windows.Forms.Label();
            this.lblx11 = new System.Windows.Forms.Label();
            this.lblx12 = new System.Windows.Forms.Label();
            this.lblx12answer = new System.Windows.Forms.Label();
            this.lblx11answer = new System.Windows.Forms.Label();
            this.lblx10answer = new System.Windows.Forms.Label();
            this.lblx9answer = new System.Windows.Forms.Label();
            this.lblx8answer = new System.Windows.Forms.Label();
            this.lblx7answer = new System.Windows.Forms.Label();
            this.lblx6answer = new System.Windows.Forms.Label();
            this.lblx5answer = new System.Windows.Forms.Label();
            this.lblx4answer = new System.Windows.Forms.Label();
            this.lblx3answer = new System.Windows.Forms.Label();
            this.lblx2answer = new System.Windows.Forms.Label();
            this.lblx1answer = new System.Windows.Forms.Label();
            this.lbtimesinstructions = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.grptriangles = new System.Windows.Forms.GroupBox();
            this.txtside1 = new System.Windows.Forms.TextBox();
            this.txtside2 = new System.Windows.Forms.TextBox();
            this.txtside3 = new System.Windows.Forms.TextBox();
            this.lblsides = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.lblthetriangleis = new System.Windows.Forms.Label();
            this.pbtriangle = new System.Windows.Forms.PictureBox();
            this.grpangles = new System.Windows.Forms.GroupBox();
            this.txtangle = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnangle = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.lblangleresult = new System.Windows.Forms.Label();
            this.pbangle = new System.Windows.Forms.PictureBox();
            this.grptimestables.SuspendLayout();
            this.grptriangles.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbtriangle)).BeginInit();
            this.grpangles.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbangle)).BeginInit();
            this.SuspendLayout();
            // 
            // grptimestables
            // 
            this.grptimestables.Controls.Add(this.label13);
            this.grptimestables.Controls.Add(this.lbtimesinstructions);
            this.grptimestables.Controls.Add(this.lblx12answer);
            this.grptimestables.Controls.Add(this.lblx11answer);
            this.grptimestables.Controls.Add(this.lblx10answer);
            this.grptimestables.Controls.Add(this.lblx9answer);
            this.grptimestables.Controls.Add(this.lblx8answer);
            this.grptimestables.Controls.Add(this.lblx7answer);
            this.grptimestables.Controls.Add(this.lblx6answer);
            this.grptimestables.Controls.Add(this.lblx5answer);
            this.grptimestables.Controls.Add(this.lblx4answer);
            this.grptimestables.Controls.Add(this.lblx3answer);
            this.grptimestables.Controls.Add(this.lblx2answer);
            this.grptimestables.Controls.Add(this.lblx1answer);
            this.grptimestables.Controls.Add(this.lblx12);
            this.grptimestables.Controls.Add(this.lblx11);
            this.grptimestables.Controls.Add(this.lblx10);
            this.grptimestables.Controls.Add(this.lblx9);
            this.grptimestables.Controls.Add(this.lblx8);
            this.grptimestables.Controls.Add(this.lblx7);
            this.grptimestables.Controls.Add(this.lblx6);
            this.grptimestables.Controls.Add(this.lblx5);
            this.grptimestables.Controls.Add(this.lblx4);
            this.grptimestables.Controls.Add(this.lblx3);
            this.grptimestables.Controls.Add(this.lblx2);
            this.grptimestables.Controls.Add(this.lblx1);
            this.grptimestables.Controls.Add(this.btntimestablesubmit);
            this.grptimestables.Controls.Add(this.txttimestable);
            this.grptimestables.Controls.Add(this.lblrtimetableesult);
            this.grptimestables.Location = new System.Drawing.Point(33, 13);
            this.grptimestables.Name = "grptimestables";
            this.grptimestables.Size = new System.Drawing.Size(350, 277);
            this.grptimestables.TabIndex = 0;
            this.grptimestables.TabStop = false;
            this.grptimestables.Text = "times table";
            // 
            // lblrtimetableesult
            // 
            this.lblrtimetableesult.AutoSize = true;
            this.lblrtimetableesult.Location = new System.Drawing.Point(220, 16);
            this.lblrtimetableesult.Name = "lblrtimetableesult";
            this.lblrtimetableesult.Size = new System.Drawing.Size(40, 13);
            this.lblrtimetableesult.TabIndex = 0;
            this.lblrtimetableesult.Text = "Result:";
            // 
            // txttimestable
            // 
            this.txttimestable.Location = new System.Drawing.Point(6, 19);
            this.txttimestable.Name = "txttimestable";
            this.txttimestable.Size = new System.Drawing.Size(100, 20);
            this.txttimestable.TabIndex = 1;
            // 
            // btntimestablesubmit
            // 
            this.btntimestablesubmit.Location = new System.Drawing.Point(112, 19);
            this.btntimestablesubmit.Name = "btntimestablesubmit";
            this.btntimestablesubmit.Size = new System.Drawing.Size(75, 20);
            this.btntimestablesubmit.TabIndex = 2;
            this.btntimestablesubmit.Text = "submit";
            this.btntimestablesubmit.UseVisualStyleBackColor = true;
            this.btntimestablesubmit.Click += new System.EventHandler(this.btntimestablesubmit_Click);
            // 
            // lblx1
            // 
            this.lblx1.AutoSize = true;
            this.lblx1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx1.Location = new System.Drawing.Point(222, 30);
            this.lblx1.Name = "lblx1";
            this.lblx1.Size = new System.Drawing.Size(38, 20);
            this.lblx1.TabIndex = 3;
            this.lblx1.Text = "x1 =";
            // 
            // lblx2
            // 
            this.lblx2.AutoSize = true;
            this.lblx2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx2.Location = new System.Drawing.Point(222, 50);
            this.lblx2.Name = "lblx2";
            this.lblx2.Size = new System.Drawing.Size(38, 20);
            this.lblx2.TabIndex = 4;
            this.lblx2.Text = "x2 =";
            // 
            // lblx3
            // 
            this.lblx3.AutoSize = true;
            this.lblx3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx3.Location = new System.Drawing.Point(219, 70);
            this.lblx3.Name = "lblx3";
            this.lblx3.Size = new System.Drawing.Size(38, 20);
            this.lblx3.TabIndex = 5;
            this.lblx3.Text = "x3 =";
            // 
            // lblx4
            // 
            this.lblx4.AutoSize = true;
            this.lblx4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx4.Location = new System.Drawing.Point(222, 90);
            this.lblx4.Name = "lblx4";
            this.lblx4.Size = new System.Drawing.Size(38, 20);
            this.lblx4.TabIndex = 6;
            this.lblx4.Text = "x4 =";
            // 
            // lblx5
            // 
            this.lblx5.AutoSize = true;
            this.lblx5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx5.Location = new System.Drawing.Point(221, 112);
            this.lblx5.Name = "lblx5";
            this.lblx5.Size = new System.Drawing.Size(38, 20);
            this.lblx5.TabIndex = 7;
            this.lblx5.Text = "x5 =";
            // 
            // lblx6
            // 
            this.lblx6.AutoSize = true;
            this.lblx6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx6.Location = new System.Drawing.Point(221, 132);
            this.lblx6.Name = "lblx6";
            this.lblx6.Size = new System.Drawing.Size(38, 20);
            this.lblx6.TabIndex = 8;
            this.lblx6.Text = "x6 =";
            // 
            // lblx7
            // 
            this.lblx7.AutoSize = true;
            this.lblx7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx7.Location = new System.Drawing.Point(221, 152);
            this.lblx7.Name = "lblx7";
            this.lblx7.Size = new System.Drawing.Size(38, 20);
            this.lblx7.TabIndex = 9;
            this.lblx7.Text = "x7 =";
            // 
            // lblx8
            // 
            this.lblx8.AutoSize = true;
            this.lblx8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx8.Location = new System.Drawing.Point(219, 172);
            this.lblx8.Name = "lblx8";
            this.lblx8.Size = new System.Drawing.Size(38, 20);
            this.lblx8.TabIndex = 10;
            this.lblx8.Text = "x8 =";
            // 
            // lblx9
            // 
            this.lblx9.AutoSize = true;
            this.lblx9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx9.Location = new System.Drawing.Point(221, 192);
            this.lblx9.Name = "lblx9";
            this.lblx9.Size = new System.Drawing.Size(38, 20);
            this.lblx9.TabIndex = 11;
            this.lblx9.Text = "x9 =";
            // 
            // lblx10
            // 
            this.lblx10.AutoSize = true;
            this.lblx10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx10.Location = new System.Drawing.Point(221, 212);
            this.lblx10.Name = "lblx10";
            this.lblx10.Size = new System.Drawing.Size(47, 20);
            this.lblx10.TabIndex = 12;
            this.lblx10.Text = "x10 =";
            // 
            // lblx11
            // 
            this.lblx11.AutoSize = true;
            this.lblx11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx11.Location = new System.Drawing.Point(221, 232);
            this.lblx11.Name = "lblx11";
            this.lblx11.Size = new System.Drawing.Size(47, 20);
            this.lblx11.TabIndex = 13;
            this.lblx11.Text = "x11 =";
            // 
            // lblx12
            // 
            this.lblx12.AutoSize = true;
            this.lblx12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx12.Location = new System.Drawing.Point(221, 252);
            this.lblx12.Name = "lblx12";
            this.lblx12.Size = new System.Drawing.Size(47, 20);
            this.lblx12.TabIndex = 14;
            this.lblx12.Text = "x12 =";
            // 
            // lblx12answer
            // 
            this.lblx12answer.AutoSize = true;
            this.lblx12answer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx12answer.Location = new System.Drawing.Point(265, 252);
            this.lblx12answer.Name = "lblx12answer";
            this.lblx12answer.Size = new System.Drawing.Size(80, 20);
            this.lblx12answer.TabIndex = 26;
            this.lblx12answer.Text = "undefined";
            // 
            // lblx11answer
            // 
            this.lblx11answer.AutoSize = true;
            this.lblx11answer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx11answer.Location = new System.Drawing.Point(265, 232);
            this.lblx11answer.Name = "lblx11answer";
            this.lblx11answer.Size = new System.Drawing.Size(80, 20);
            this.lblx11answer.TabIndex = 25;
            this.lblx11answer.Text = "undefined";
            // 
            // lblx10answer
            // 
            this.lblx10answer.AutoSize = true;
            this.lblx10answer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx10answer.Location = new System.Drawing.Point(265, 212);
            this.lblx10answer.Name = "lblx10answer";
            this.lblx10answer.Size = new System.Drawing.Size(80, 20);
            this.lblx10answer.TabIndex = 24;
            this.lblx10answer.Text = "undefined";
            // 
            // lblx9answer
            // 
            this.lblx9answer.AutoSize = true;
            this.lblx9answer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx9answer.Location = new System.Drawing.Point(265, 192);
            this.lblx9answer.Name = "lblx9answer";
            this.lblx9answer.Size = new System.Drawing.Size(80, 20);
            this.lblx9answer.TabIndex = 23;
            this.lblx9answer.Text = "undefined";
            // 
            // lblx8answer
            // 
            this.lblx8answer.AutoSize = true;
            this.lblx8answer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx8answer.Location = new System.Drawing.Point(263, 172);
            this.lblx8answer.Name = "lblx8answer";
            this.lblx8answer.Size = new System.Drawing.Size(80, 20);
            this.lblx8answer.TabIndex = 22;
            this.lblx8answer.Text = "undefined";
            // 
            // lblx7answer
            // 
            this.lblx7answer.AutoSize = true;
            this.lblx7answer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx7answer.Location = new System.Drawing.Point(265, 152);
            this.lblx7answer.Name = "lblx7answer";
            this.lblx7answer.Size = new System.Drawing.Size(80, 20);
            this.lblx7answer.TabIndex = 21;
            this.lblx7answer.Text = "undefined";
            // 
            // lblx6answer
            // 
            this.lblx6answer.AutoSize = true;
            this.lblx6answer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx6answer.Location = new System.Drawing.Point(265, 132);
            this.lblx6answer.Name = "lblx6answer";
            this.lblx6answer.Size = new System.Drawing.Size(80, 20);
            this.lblx6answer.TabIndex = 20;
            this.lblx6answer.Text = "undefined";
            // 
            // lblx5answer
            // 
            this.lblx5answer.AutoSize = true;
            this.lblx5answer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx5answer.Location = new System.Drawing.Point(265, 112);
            this.lblx5answer.Name = "lblx5answer";
            this.lblx5answer.Size = new System.Drawing.Size(80, 20);
            this.lblx5answer.TabIndex = 19;
            this.lblx5answer.Text = "undefined";
            // 
            // lblx4answer
            // 
            this.lblx4answer.AutoSize = true;
            this.lblx4answer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx4answer.Location = new System.Drawing.Point(266, 90);
            this.lblx4answer.Name = "lblx4answer";
            this.lblx4answer.Size = new System.Drawing.Size(80, 20);
            this.lblx4answer.TabIndex = 18;
            this.lblx4answer.Text = "undefined";
            // 
            // lblx3answer
            // 
            this.lblx3answer.AutoSize = true;
            this.lblx3answer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx3answer.Location = new System.Drawing.Point(263, 70);
            this.lblx3answer.Name = "lblx3answer";
            this.lblx3answer.Size = new System.Drawing.Size(80, 20);
            this.lblx3answer.TabIndex = 17;
            this.lblx3answer.Text = "undefined";
            // 
            // lblx2answer
            // 
            this.lblx2answer.AutoSize = true;
            this.lblx2answer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx2answer.Location = new System.Drawing.Point(266, 50);
            this.lblx2answer.Name = "lblx2answer";
            this.lblx2answer.Size = new System.Drawing.Size(80, 20);
            this.lblx2answer.TabIndex = 16;
            this.lblx2answer.Text = "undefined";
            // 
            // lblx1answer
            // 
            this.lblx1answer.AutoSize = true;
            this.lblx1answer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblx1answer.Location = new System.Drawing.Point(266, 30);
            this.lblx1answer.Name = "lblx1answer";
            this.lblx1answer.Size = new System.Drawing.Size(80, 20);
            this.lblx1answer.TabIndex = 15;
            this.lblx1answer.Text = "undefined";
            // 
            // lbtimesinstructions
            // 
            this.lbtimesinstructions.AutoSize = true;
            this.lbtimesinstructions.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbtimesinstructions.Location = new System.Drawing.Point(7, 46);
            this.lbtimesinstructions.Name = "lbtimesinstructions";
            this.lbtimesinstructions.Size = new System.Drawing.Size(104, 24);
            this.lbtimesinstructions.TabIndex = 27;
            this.lbtimesinstructions.Text = "instructions";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(7, 72);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(189, 32);
            this.label13.TabIndex = 28;
            this.label13.Text = "enter a number into the text box\r\nthen click the button";
            // 
            // grptriangles
            // 
            this.grptriangles.Controls.Add(this.label1);
            this.grptriangles.Controls.Add(this.label2);
            this.grptriangles.Controls.Add(this.pbtriangle);
            this.grptriangles.Controls.Add(this.lblthetriangleis);
            this.grptriangles.Controls.Add(this.button1);
            this.grptriangles.Controls.Add(this.lblsides);
            this.grptriangles.Controls.Add(this.txtside3);
            this.grptriangles.Controls.Add(this.txtside2);
            this.grptriangles.Controls.Add(this.txtside1);
            this.grptriangles.Location = new System.Drawing.Point(441, 13);
            this.grptriangles.Name = "grptriangles";
            this.grptriangles.Size = new System.Drawing.Size(424, 272);
            this.grptriangles.TabIndex = 1;
            this.grptriangles.TabStop = false;
            this.grptriangles.Text = "triangles";
            this.grptriangles.Enter += new System.EventHandler(this.grptriangles_Enter);
            // 
            // txtside1
            // 
            this.txtside1.Location = new System.Drawing.Point(7, 19);
            this.txtside1.Name = "txtside1";
            this.txtside1.Size = new System.Drawing.Size(100, 20);
            this.txtside1.TabIndex = 0;
            // 
            // txtside2
            // 
            this.txtside2.Location = new System.Drawing.Point(6, 43);
            this.txtside2.Name = "txtside2";
            this.txtside2.Size = new System.Drawing.Size(100, 20);
            this.txtside2.TabIndex = 1;
            // 
            // txtside3
            // 
            this.txtside3.Location = new System.Drawing.Point(6, 69);
            this.txtside3.Name = "txtside3";
            this.txtside3.Size = new System.Drawing.Size(100, 20);
            this.txtside3.TabIndex = 2;
            // 
            // lblsides
            // 
            this.lblsides.AutoSize = true;
            this.lblsides.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsides.Location = new System.Drawing.Point(6, 97);
            this.lblsides.Name = "lblsides";
            this.lblsides.Size = new System.Drawing.Size(115, 20);
            this.lblsides.TabIndex = 3;
            this.lblsides.Text = "the triangle is...";
            this.lblsides.Click += new System.EventHandler(this.lblsides_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(112, 43);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "submit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblthetriangleis
            // 
            this.lblthetriangleis.AutoSize = true;
            this.lblthetriangleis.Location = new System.Drawing.Point(7, 121);
            this.lblthetriangleis.Name = "lblthetriangleis";
            this.lblthetriangleis.Size = new System.Drawing.Size(0, 13);
            this.lblthetriangleis.TabIndex = 5;
            // 
            // pbtriangle
            // 
            this.pbtriangle.Location = new System.Drawing.Point(209, 43);
            this.pbtriangle.Name = "pbtriangle";
            this.pbtriangle.Size = new System.Drawing.Size(209, 209);
            this.pbtriangle.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbtriangle.TabIndex = 6;
            this.pbtriangle.TabStop = false;
            // 
            // grpangles
            // 
            this.grpangles.Controls.Add(this.pbangle);
            this.grpangles.Controls.Add(this.lblangleresult);
            this.grpangles.Controls.Add(this.label5);
            this.grpangles.Controls.Add(this.btnangle);
            this.grpangles.Controls.Add(this.label3);
            this.grpangles.Controls.Add(this.label4);
            this.grpangles.Controls.Add(this.txtangle);
            this.grpangles.Location = new System.Drawing.Point(33, 312);
            this.grpangles.Name = "grpangles";
            this.grpangles.Size = new System.Drawing.Size(350, 281);
            this.grpangles.TabIndex = 2;
            this.grpangles.TabStop = false;
            this.grpangles.Text = "angles";
            // 
            // txtangle
            // 
            this.txtangle.Location = new System.Drawing.Point(10, 20);
            this.txtangle.Name = "txtangle";
            this.txtangle.Size = new System.Drawing.Size(100, 20);
            this.txtangle.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 235);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(202, 32);
            this.label1.TabIndex = 30;
            this.label1.Text = "enter the numbers into the 3 text \r\nboxes provided and click submit.";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 209);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 24);
            this.label2.TabIndex = 29;
            this.label2.Text = "instructions";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 246);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(189, 32);
            this.label3.TabIndex = 30;
            this.label3.Text = "enter a number into the text box\r\nthen click the button";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(3, 220);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(104, 24);
            this.label4.TabIndex = 29;
            this.label4.Text = "instructions";
            // 
            // btnangle
            // 
            this.btnangle.Location = new System.Drawing.Point(112, 19);
            this.btnangle.Name = "btnangle";
            this.btnangle.Size = new System.Drawing.Size(75, 23);
            this.btnangle.TabIndex = 31;
            this.btnangle.Text = "submit`";
            this.btnangle.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(7, 43);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(102, 20);
            this.label5.TabIndex = 31;
            this.label5.Text = "the angle is...";
            // 
            // lblangleresult
            // 
            this.lblangleresult.AutoSize = true;
            this.lblangleresult.Location = new System.Drawing.Point(8, 63);
            this.lblangleresult.Name = "lblangleresult";
            this.lblangleresult.Size = new System.Drawing.Size(0, 13);
            this.lblangleresult.TabIndex = 32;
            // 
            // pbangle
            // 
            this.pbangle.Location = new System.Drawing.Point(131, 43);
            this.pbangle.Name = "pbangle";
            this.pbangle.Size = new System.Drawing.Size(212, 186);
            this.pbangle.TabIndex = 33;
            this.pbangle.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightCyan;
            this.ClientSize = new System.Drawing.Size(891, 761);
            this.Controls.Add(this.grpangles);
            this.Controls.Add(this.grptriangles);
            this.Controls.Add(this.grptimestables);
            this.Name = "Form1";
            this.Text = "Form1";
            this.grptimestables.ResumeLayout(false);
            this.grptimestables.PerformLayout();
            this.grptriangles.ResumeLayout(false);
            this.grptriangles.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbtriangle)).EndInit();
            this.grpangles.ResumeLayout(false);
            this.grpangles.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbangle)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grptimestables;
        private System.Windows.Forms.Label lblx7;
        private System.Windows.Forms.Label lblx6;
        private System.Windows.Forms.Label lblx5;
        private System.Windows.Forms.Label lblx4;
        private System.Windows.Forms.Label lblx3;
        private System.Windows.Forms.Label lblx2;
        private System.Windows.Forms.Label lblx1;
        private System.Windows.Forms.Button btntimestablesubmit;
        private System.Windows.Forms.TextBox txttimestable;
        private System.Windows.Forms.Label lblrtimetableesult;
        private System.Windows.Forms.Label lblx12;
        private System.Windows.Forms.Label lblx11;
        private System.Windows.Forms.Label lblx10;
        private System.Windows.Forms.Label lblx9;
        private System.Windows.Forms.Label lblx8;
        private System.Windows.Forms.Label lblx12answer;
        private System.Windows.Forms.Label lblx11answer;
        private System.Windows.Forms.Label lblx10answer;
        private System.Windows.Forms.Label lblx9answer;
        private System.Windows.Forms.Label lblx8answer;
        private System.Windows.Forms.Label lblx7answer;
        private System.Windows.Forms.Label lblx6answer;
        private System.Windows.Forms.Label lblx5answer;
        private System.Windows.Forms.Label lblx4answer;
        private System.Windows.Forms.Label lblx3answer;
        private System.Windows.Forms.Label lblx2answer;
        private System.Windows.Forms.Label lblx1answer;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lbtimesinstructions;
        private System.Windows.Forms.GroupBox grptriangles;
        private System.Windows.Forms.TextBox txtside3;
        private System.Windows.Forms.TextBox txtside2;
        private System.Windows.Forms.TextBox txtside1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lblsides;
        private System.Windows.Forms.Label lblthetriangleis;
        private System.Windows.Forms.PictureBox pbtriangle;
        private System.Windows.Forms.GroupBox grpangles;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnangle;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtangle;
        private System.Windows.Forms.Label lblangleresult;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pbangle;
    }
}

